package model.progelement;

import java.util.List;

public class LocationElement extends ProgramElement {
   private String pkgName;
   private String className;
   private List<?> parameters;
   private String loc;

   public LocationElement(String name, ProgramElement parent) {
      super(name, parent);
      setLoc("5");
   }

   public void setParameters(List<?> parameters) {
      this.parameters = parameters;
   }

   public List<?> getParameters() {
      return parameters;
   }

   public String getLoc() {
	   return loc;
   }
   
   private void setLoc (String s) {
	   loc = s;
   }
}
