package model.provider;

import org.eclipse.jface.viewers.StyledString;

import model.progelement.LocationElement;

public class LabelProviderLocationParameter extends LabelProviderProgElem {

	@Override
	public StyledString getStyledText(Object element) {
		if (element instanceof LocationElement) {
			return new StyledString(((LocationElement) element).getLoc());
		}
		return new StyledString(""); // super.getStyledText(element);
	}
}
